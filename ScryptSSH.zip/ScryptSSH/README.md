# SEJAM TODOS BEM VINDOS!!
########################################
# SSH-PRO 2022
########################################
# BY JSNETDEV OFICIAL
########################################
*AGRADECEMOS A SUA PREFERÊNCA..
########################################

# Modo de instalação 🔰
# 
Só joga na máquina e deixar instalar✔️

• atualiza sistema

• desativa Ipv6

• instala recursos e o script 👇
```
apt install wget -y; bash <(wget -qO- raw.githubusercontent.com/jsnetdev/ScryptSSH/main/ssh-plus)

```
